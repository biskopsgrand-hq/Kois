import { useMemo, useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, Check, Pencil, Plus, Printer, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AccountChip } from "@/components/budget/account-chip";
import { AdminNav } from "@/components/budget/auth-gate";
import { BrandLockup } from "@/components/budget/brand-lockup";
import { currentFiscalYear, formatKr, parseAmountInput } from "@/lib/format";
import { memberFee, useBudgetStore, type Member } from "@/lib/budget-store";
import { cn } from "@/lib/utils";

type MemberForm = {
  name: string;
  property: string;
  email: string;
  phone: string;
  andelstal: string;
  active: boolean;
};

const EMPTY_FORM: MemberForm = {
  name: "",
  property: "",
  email: "",
  phone: "",
  andelstal: "1",
  active: true,
};

export function MembersApp() {
  const members = useBudgetStore((s) => s.members);
  const payments = useBudgetStore((s) => s.payments);
  const annualFeeTarget = useBudgetStore((s) => s.annualFeeTarget);
  const addMember = useBudgetStore((s) => s.addMember);
  const updateMember = useBudgetStore((s) => s.updateMember);
  const deleteMember = useBudgetStore((s) => s.deleteMember);
  const togglePayment = useBudgetStore((s) => s.togglePayment);
  const setAnnualFeeTarget = useBudgetStore((s) => s.setAnnualFeeTarget);

  const [year] = useState(currentFiscalYear());
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Member | null>(null);
  const [form, setForm] = useState<MemberForm>(EMPTY_FORM);
  const [pendingDelete, setPendingDelete] = useState<Member | null>(null);
  const [feeInput, setFeeInput] = useState<string | null>(null);

  const activeMembers = useMemo(() => members.filter((m) => m.active), [members]);
  const totalAndelstal = useMemo(
    () => activeMembers.reduce((sum, m) => sum + m.andelstal, 0),
    [activeMembers],
  );

  function openCreate() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setFormOpen(true);
  }

  function openEdit(member: Member) {
    setEditing(member);
    setForm({
      name: member.name,
      property: member.property,
      email: member.email,
      phone: member.phone,
      andelstal: String(member.andelstal),
      active: member.active,
    });
    setFormOpen(true);
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const andelstal = parseFloat(form.andelstal.replace(",", "."));
    if (!form.name.trim()) {
      toast.error("Namn krävs.");
      return;
    }
    if (!andelstal || andelstal <= 0) {
      toast.error("Andelstal måste vara större än 0.");
      return;
    }
    const data = {
      name: form.name.trim(),
      property: form.property.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      andelstal,
      active: form.active,
    };
    if (editing) {
      updateMember(editing.id, data);
      toast("Medlemmen uppdaterades");
    } else {
      addMember(data);
      toast("Medlemmen lades till");
    }
    setFormOpen(false);
  }

  function commitFeeTarget() {
    if (feeInput === null) return;
    const parsed = parseAmountInput(feeInput);
    if (parsed !== null) setAnnualFeeTarget(parsed);
    setFeeInput(null);
  }

  function isPaid(memberId: string) {
    return payments.some((p) => p.memberId === memberId && p.year === year && p.paid);
  }

  const paidCount = activeMembers.filter((m) => isPaid(m.id)).length;
  const collectedAmount = activeMembers
    .filter((m) => isPaid(m.id))
    .reduce((sum, m) => sum + memberFee(m, totalAndelstal, annualFeeTarget), 0);

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-4xl min-w-0 flex-col overflow-x-clip px-4 pt-6 pb-10 sm:px-6 lg:px-8">
      <header className="mb-6 flex flex-col gap-4 print:mb-8 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          <BrandLockup page="Fakturering" />
          <p className="mt-1 text-sm text-muted">Räkenskapsår {year}/{year + 1}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2 print:hidden">
          <AccountChip />
          <AdminNav />
          <Button variant="outline" asChild>
            <Link to="/">
              <ArrowLeft />
              Budget
            </Link>
          </Button>
          <Button onClick={() => window.print()}>
            <Printer />
            Skriv ut
          </Button>
        </div>
      </header>

      {/* Fee target + summary */}
      <section className="mb-6 rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div className="grid gap-2">
            <Label htmlFor="fee-target">Total årsavgift att ta in (kr)</Label>
            <Input
              id="fee-target"
              inputMode="decimal"
              className="tabular-nums w-52"
              value={feeInput ?? String(annualFeeTarget)}
              onChange={(e) => setFeeInput(e.target.value)}
              onBlur={commitFeeTarget}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  commitFeeTarget();
                }
              }}
              placeholder="0"
            />
          </div>
          <div className="flex flex-wrap gap-4">
            <Stat label="Inbetalat" value={formatKr(collectedAmount)} />
            <Stat label="Återstår" value={formatKr(Math.max(0, annualFeeTarget - collectedAmount))} />
            <Stat label={`Betalat ${paidCount}/${activeMembers.length}`} value="" />
          </div>
        </div>
        {totalAndelstal > 0 && (
          <p className="mt-3 text-sm text-muted print:hidden">
            Totalt andelstal: {totalAndelstal.toLocaleString("sv-SE")}. Ange summan ovan och avgiften per fastighet beräknas automatiskt.
          </p>
        )}
      </section>

      {/* Member list */}
      <section className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6">
        <div className="mb-4 flex items-center justify-between gap-3 print:hidden">
          <h2 className="text-lg font-medium text-ink">Fastigheter och avgifter</h2>
          <Button onClick={openCreate}>
            <Plus />
            Lägg till
          </Button>
        </div>
        <div className="mb-4 hidden print:block">
          <h2 className="text-xl font-medium">Avgiftsavier {year}/{year + 1}</h2>
          <p className="text-sm text-muted">Total avgift: {formatKr(annualFeeTarget)}</p>
        </div>

        {activeMembers.length === 0 ? (
          <div className="rounded-lg bg-bg px-4 py-8 text-center">
            <p className="text-sm text-muted">Inga fastigheter ännu. Lägg till för att beräkna avgifter.</p>
            <Button className="mt-4" variant="outline" onClick={openCreate}>
              <Plus />
              Lägg till fastighet
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line text-left text-xs font-medium uppercase tracking-wide text-muted">
                  <th className="pb-2 pr-4">Fastighet / Ägare</th>
                  <th className="pb-2 pr-4 text-right">Andelstal</th>
                  <th className="pb-2 pr-4 text-right">Avgift {year}/{year + 1}</th>
                  <th className="pb-2 pr-4 text-center print:hidden">Betald</th>
                  <th className="pb-2 print:hidden" />
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {activeMembers.map((member) => {
                  const fee = memberFee(member, totalAndelstal, annualFeeTarget);
                  const paid = isPaid(member.id);
                  return (
                    <tr key={member.id} className={cn(paid && "opacity-60")}>
                      <td className="py-3 pr-4">
                        <p className="font-medium text-ink">{member.name}</p>
                        {member.property && (
                          <p className="text-xs text-muted">{member.property}</p>
                        )}
                        {member.email && (
                          <p className="text-xs text-muted">{member.email}</p>
                        )}
                      </td>
                      <td className="py-3 pr-4 text-right tabular-nums text-ink">
                        {member.andelstal.toLocaleString("sv-SE")}
                      </td>
                      <td className="py-3 pr-4 text-right tabular-nums font-medium text-ink">
                        {annualFeeTarget > 0 ? formatKr(fee) : "—"}
                      </td>
                      <td className="py-3 pr-4 text-center print:hidden">
                        <button
                          type="button"
                          onClick={() => togglePayment(member.id, year)}
                          className={cn(
                            "mx-auto flex h-6 w-6 items-center justify-center rounded border transition-colors",
                            paid
                              ? "border-moss bg-moss text-white"
                              : "border-line bg-surface-2 text-transparent hover:border-muted",
                          )}
                          aria-label={paid ? "Markera som obetald" : "Markera som betald"}
                        >
                          <Check className="size-3.5" />
                        </button>
                      </td>
                      <td className="py-3 print:hidden">
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            className="text-muted"
                            onClick={() => openEdit(member)}
                            aria-label="Redigera"
                          >
                            <Pencil />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            className="text-muted hover:text-clay"
                            onClick={() => setPendingDelete(member)}
                            aria-label="Ta bort"
                          >
                            <Trash2 />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              {annualFeeTarget > 0 && activeMembers.length > 0 && (
                <tfoot>
                  <tr className="border-t border-ink/20">
                    <td className="pt-2 font-medium text-ink">Summa</td>
                    <td className="pt-2 pr-4 text-right tabular-nums font-medium text-ink">
                      {totalAndelstal.toLocaleString("sv-SE")}
                    </td>
                    <td className="pt-2 pr-4 text-right tabular-nums font-medium text-ink">
                      {formatKr(annualFeeTarget)}
                    </td>
                    <td colSpan={2} className="print:hidden" />
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        )}
      </section>

      {/* Inactive members */}
      {members.some((m) => !m.active) && (
        <section className="mt-6 rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)] print:hidden sm:p-6">
          <h2 className="mb-3 text-sm font-medium text-muted">Inaktiva fastigheter</h2>
          <ul className="divide-y divide-line">
            {members
              .filter((m) => !m.active)
              .map((member) => (
                <li key={member.id} className="flex items-center justify-between gap-3 py-2">
                  <div>
                    <p className="text-sm text-muted">{member.name}</p>
                    {member.property && <p className="text-xs text-subtle">{member.property}</p>}
                  </div>
                  <Button variant="ghost" size="icon-sm" className="text-muted" onClick={() => openEdit(member)}>
                    <Pencil />
                  </Button>
                </li>
              ))}
          </ul>
        </section>
      )}

      {/* Member form dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? "Redigera fastighet" : "Lägg till fastighet"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="m-name">Ägare / Namn *</Label>
              <Input
                id="m-name"
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="Förnamn Efternamn"
                maxLength={80}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="m-property">Fastighetsbeteckning</Label>
              <Input
                id="m-property"
                value={form.property}
                onChange={(e) => setForm((f) => ({ ...f, property: e.target.value }))}
                placeholder="Koholma 1:23"
                maxLength={40}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label htmlFor="m-email">E-post</Label>
                <Input
                  id="m-email"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="m-phone">Telefon</Label>
                <Input
                  id="m-phone"
                  type="tel"
                  value={form.phone}
                  onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="m-andelstal">Andelstal</Label>
              <Input
                id="m-andelstal"
                inputMode="decimal"
                className="tabular-nums"
                value={form.andelstal}
                onChange={(e) => setForm((f) => ({ ...f, andelstal: e.target.value }))}
                placeholder="1"
              />
            </div>
            <label className="flex items-center gap-2 text-sm text-ink">
              <input
                type="checkbox"
                checked={form.active}
                onChange={(e) => setForm((f) => ({ ...f, active: e.target.checked }))}
                className="h-4 w-4 rounded border-line accent-moss"
              />
              Aktiv (ingår i avgiftsberäkning)
            </label>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setFormOpen(false)}>
                Avbryt
              </Button>
              <Button type="submit">{editing ? "Spara" : "Lägg till"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!pendingDelete} onOpenChange={(open) => !open && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Ta bort fastigheten?</AlertDialogTitle>
            <AlertDialogDescription>
              {pendingDelete?.name} tas bort permanent inklusive betalningsinformation.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Avbryt</AlertDialogCancel>
            <AlertDialogAction
              className="bg-clay text-destructive-foreground hover:bg-clay/90"
              onClick={() => {
                if (!pendingDelete) return;
                deleteMember(pendingDelete.id);
                toast("Fastigheten togs bort");
                setPendingDelete(null);
              }}
            >
              Ta bort
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-bg px-3 py-2">
      <p className="text-xs font-medium uppercase tracking-wide text-muted">{label}</p>
      {value && <p className="mt-0.5 text-base font-medium tabular-nums text-ink">{value}</p>}
    </div>
  );
}
