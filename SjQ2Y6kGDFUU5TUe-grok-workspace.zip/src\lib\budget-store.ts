import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  DEFAULT_CATEGORIES,
  fallbackCategoryId,
  findDuplicate,
  nextSwatch,
  type Category,
  type TxType,
} from "@/lib/categories";
import { currentFiscalYear, monthKeyFromDate } from "@/lib/format";

export type Transaction = {
  id: string;
  type: TxType;
  amount: number;
  categoryId: string;
  note: string;
  date: string;
};

export type TransactionInput = Omit<Transaction, "id"> & { id?: string };

export type BalanceItem = {
  id: string;
  name: string;
  amount: number;
};

export type YearBook = {
  openingCash: number;
  assets: BalanceItem[];
  liabilities: BalanceItem[];
};

export const EMPTY_YEAR_BOOK: YearBook = {
  openingCash: 0,
  assets: [],
  liabilities: [],
};

export type Member = {
  id: string;
  name: string;
  property: string;
  email: string;
  phone: string;
  andelstal: number;
  active: boolean;
};

export type Payment = {
  memberId: string;
  year: number;
  paid: boolean;
  paidDate?: string;
};

type BalanceKind = "assets" | "liabilities";

type BudgetState = {
  transactions: Transaction[];
  categories: Category[];
  monthlyBudget: number;
  selectedMonth: string;
  yearBooks: Record<string, YearBook>;
  members: Member[];
  payments: Payment[];
  annualFeeTarget: number;
  addTransaction: (input: TransactionInput) => void;
  updateTransaction: (id: string, input: TransactionInput) => void;
  deleteTransaction: (id: string) => void;
  addCategory: (name: string, type: TxType) => string | null;
  renameCategory: (id: string, name: string) => boolean;
  deleteCategory: (id: string) => boolean;
  setMonthlyBudget: (amount: number) => void;
  setSelectedMonth: (month: string) => void;
  setOpeningCash: (year: number, amount: number) => void;
  addBalanceItem: (year: number, kind: BalanceKind, name: string, amount: number) => string | null;
  removeBalanceItem: (year: number, kind: BalanceKind, id: string) => void;
  addMember: (input: Omit<Member, "id">) => string;
  updateMember: (id: string, input: Omit<Member, "id">) => void;
  deleteMember: (id: string) => void;
  togglePayment: (memberId: string, year: number) => void;
  setAnnualFeeTarget: (amount: number) => void;
};

function seedMonth(): string {
  return monthKeyFromDate(new Date());
}

function bookFor(books: Record<string, YearBook>, year: number): YearBook {
  return books[String(year)] ?? EMPTY_YEAR_BOOK;
}

const initialMonth = seedMonth();

export const useBudgetStore = create<BudgetState>()(
  persist(
    (set, get) => ({
      transactions: [],
      categories: DEFAULT_CATEGORIES,
      monthlyBudget: 0,
      selectedMonth: initialMonth,
      yearBooks: {},
      members: [],
      payments: [],
      annualFeeTarget: 0,
      addTransaction: (input) =>
        set((state) => ({
          transactions: [
            {
              id: crypto.randomUUID(),
              type: input.type,
              amount: input.amount,
              categoryId: input.categoryId,
              note: input.note.trim(),
              date: input.date,
            },
            ...state.transactions,
          ],
        })),
      updateTransaction: (id, input) =>
        set((state) => ({
          transactions: state.transactions.map((tx) =>
            tx.id === id
              ? {
                  ...tx,
                  type: input.type,
                  amount: input.amount,
                  categoryId: input.categoryId,
                  note: input.note.trim(),
                  date: input.date,
                }
              : tx,
          ),
        })),
      deleteTransaction: (id) =>
        set((state) => ({
          transactions: state.transactions.filter((tx) => tx.id !== id),
        })),
      addCategory: (name, type) => {
        const trimmed = name.trim();
        if (!trimmed) return null;
        const { categories } = get();
        if (findDuplicate(categories, type, trimmed)) return null;
        const id = crypto.randomUUID();
        set({
          categories: [
            ...categories,
            { id, name: trimmed, type, swatch: nextSwatch(categories, type) },
          ],
        });
        return id;
      },
      renameCategory: (id, name) => {
        const trimmed = name.trim();
        if (!trimmed) return false;
        const { categories } = get();
        const current = categories.find((c) => c.id === id);
        if (!current) return false;
        if (findDuplicate(categories, current.type, trimmed, id)) return false;
        set({
          categories: categories.map((c) => (c.id === id ? { ...c, name: trimmed } : c)),
        });
        return true;
      },
      deleteCategory: (id) => {
        const { categories, transactions } = get();
        const current = categories.find((c) => c.id === id);
        if (!current) return false;
        const fallback = fallbackCategoryId(categories, current.type, id);
        if (!fallback) return false;
        set({
          categories: categories.filter((c) => c.id !== id),
          transactions: transactions.map((tx) =>
            tx.categoryId === id ? { ...tx, categoryId: fallback } : tx,
          ),
        });
        return true;
      },
      setMonthlyBudget: (monthlyBudget) => set({ monthlyBudget }),
      setSelectedMonth: (selectedMonth) => set({ selectedMonth }),
      setOpeningCash: (year, amount) =>
        set((state) => {
          const key = String(year);
          const current = bookFor(state.yearBooks, year);
          return {
            yearBooks: {
              ...state.yearBooks,
              [key]: { ...current, openingCash: amount },
            },
          };
        }),
      addBalanceItem: (year, kind, name, amount) => {
        const trimmed = name.trim();
        if (!trimmed || amount <= 0) return null;
        const id = crypto.randomUUID();
        set((state) => {
          const key = String(year);
          const current = bookFor(state.yearBooks, year);
          return {
            yearBooks: {
              ...state.yearBooks,
              [key]: { ...current, [kind]: [...current[kind], { id, name: trimmed, amount }] },
            },
          };
        });
        return id;
      },
      removeBalanceItem: (year, kind, id) =>
        set((state) => {
          const key = String(year);
          const current = bookFor(state.yearBooks, year);
          return {
            yearBooks: {
              ...state.yearBooks,
              [key]: { ...current, [kind]: current[kind].filter((item) => item.id !== id) },
            },
          };
        }),
      addMember: (input) => {
        const id = crypto.randomUUID();
        set((state) => ({ members: [...state.members, { id, ...input }] }));
        return id;
      },
      updateMember: (id, input) =>
        set((state) => ({
          members: state.members.map((m) => (m.id === id ? { id, ...input } : m)),
        })),
      deleteMember: (id) =>
        set((state) => ({
          members: state.members.filter((m) => m.id !== id),
          payments: state.payments.filter((p) => p.memberId !== id),
        })),
      togglePayment: (memberId, year) =>
        set((state) => {
          const existing = state.payments.find(
            (p) => p.memberId === memberId && p.year === year,
          );
          if (existing) {
            return {
              payments: state.payments.map((p) =>
                p.memberId === memberId && p.year === year
                  ? { ...p, paid: !p.paid, paidDate: !p.paid ? new Date().toISOString().slice(0, 10) : undefined }
                  : p,
              ),
            };
          }
          return {
            payments: [
              ...state.payments,
              { memberId, year, paid: true, paidDate: new Date().toISOString().slice(0, 10) },
            ],
          };
        }),
      setAnnualFeeTarget: (annualFeeTarget) => set({ annualFeeTarget }),
    }),
    {
      name: "koholma-budget-v1",
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<BudgetState>;
        return {
          ...current,
          ...p,
          categories:
            Array.isArray(p.categories) && p.categories.length > 0
              ? p.categories
              : current.categories,
          yearBooks:
            p.yearBooks && typeof p.yearBooks === "object" && !Array.isArray(p.yearBooks)
              ? p.yearBooks
              : current.yearBooks,
          members: Array.isArray(p.members) ? p.members : current.members,
          payments: Array.isArray(p.payments) ? p.payments : current.payments,
        };
      },
    },
  ),
);

export function monthTransactions(
  transactions: Transaction[],
  month: string,
): Transaction[] {
  return transactions
    .filter((tx) => tx.date.startsWith(month))
    .sort((a, b) => {
      if (a.date !== b.date) return a.date < b.date ? 1 : -1;
      if (a.type !== b.type) return a.type === "income" ? -1 : 1;
      return b.amount - a.amount;
    });
}

export function monthTotals(transactions: Transaction[]) {
  let income = 0;
  let expense = 0;
  for (const tx of transactions) {
    if (tx.type === "income") income += tx.amount;
    else expense += tx.amount;
  }
  return { income, expense, remaining: income - expense };
}

export function spendingByCategory(transactions: Transaction[]) {
  const map = new Map<string, number>();
  for (const tx of transactions) {
    if (tx.type !== "expense") continue;
    map.set(tx.categoryId, (map.get(tx.categoryId) ?? 0) + tx.amount);
  }
  return [...map.entries()]
    .map(([categoryId, amount]) => ({ categoryId, amount }))
    .sort((a, b) => b.amount - a.amount);
}

export function memberFee(member: Member, totalAndelstal: number, feeTarget: number): number {
  if (totalAndelstal <= 0) return 0;
  return Math.round((member.andelstal / totalAndelstal) * feeTarget);
}
