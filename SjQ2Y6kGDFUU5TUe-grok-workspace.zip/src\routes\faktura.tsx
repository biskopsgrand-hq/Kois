import { createFileRoute } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { AuthGate } from "@/components/budget/auth-gate";
import { MembersApp } from "@/components/budget/members-app";
import { APP_NAME } from "@/lib/brand";

export const Route = createFileRoute("/faktura")({
  component: FakturaPage,
  head: () => ({
    meta: [
      { title: `Fakturering — ${APP_NAME}` },
      { name: "description", content: "Hantera fastigheter, andelstal och årsavgifter." },
    ],
  }),
});

function FakturaPage() {
  return (
    <AuthGate>
      <main className="min-h-dvh overflow-x-clip bg-bg text-ink">
        <MembersApp />
        <Toaster
          position="top-center"
          offset={16}
          toastOptions={{
            className:
              "!bg-surface !text-ink !border-0 !shadow-[var(--shadow-raised)] !font-sans",
          }}
        />
      </main>
    </AuthGate>
  );
}
